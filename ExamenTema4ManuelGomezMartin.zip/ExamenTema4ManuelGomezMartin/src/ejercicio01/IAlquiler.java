package ejercicio01;

public interface IAlquiler {

	double calcularPrecio(double cantidad);
}
